---
name: Structured Minimalism
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c8c6c5'
  primary: '#c8c6c5'
  on-primary: '#313030'
  primary-container: '#121212'
  on-primary-container: '#7e7d7d'
  inverse-primary: '#5f5e5e'
  secondary: '#a1d494'
  on-secondary: '#0a3909'
  secondary-container: '#23501e'
  on-secondary-container: '#90c283'
  tertiary: '#ffb68c'
  on-tertiary: '#522300'
  tertiary-container: '#240b00'
  on-tertiary-container: '#b86937'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c8c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#bcf0ae'
  secondary-fixed-dim: '#a1d494'
  on-secondary-fixed: '#002201'
  on-secondary-fixed-variant: '#23501e'
  tertiary-fixed: '#ffdbc9'
  tertiary-fixed-dim: '#ffb68c'
  on-tertiary-fixed: '#321200'
  on-tertiary-fixed-variant: '#743503'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  headline-xl:
    fontFamily: Syne
    fontSize: 80px
    fontWeight: '800'
    lineHeight: '1.0'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Syne
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Syne
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.1'
  headline-md:
    fontFamily: Syne
    fontSize: 24px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-bold:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.2'
  caption:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.4'
spacing:
  margin-mobile: 1rem
  margin-desktop: 4rem
  gutter: 1.5rem
  block-gap-sm: 2rem
  block-gap-lg: 6rem
---

## Brand & Style
The design system is defined by a "Structured Minimalism" aesthetic, designed to evoke a sense of modern reverence and architectural stability. It targets a contemporary audience seeking clarity and depth in a digital ministry context. The visual language balances editorial sophistication with functional utility, utilizing high-contrast color blocking and a rigid grid to create a "digital magazine" experience.

The style leans heavily into **High-Contrast / Bold** layouts with a **Minimalist** ethos. It avoids decorative flourishes, relying instead on intentional negative space, massive typography, and sharp geometry to guide the user’s eye and establish a clear hierarchy of information.

## Colors
The palette is built on a dark-mode-first foundation to provide a focused, immersive experience. 

*   **Primary Base:** Deep Charcoal (#121212) serves as the canvas, providing a sophisticated backdrop for content.
*   **Accents:** Forest Green (#2D5A27) and Terracotta (#E58E58) are used for thematic grouping and organic highlights, grounding the brand in natural, earthy tones.
*   **CTA Action:** Crimson Red (#DC143C) is reserved exclusively for high-energy conversion points and critical alerts.
*   **Typography/Neutral:** Off-White (#F5F5F5) ensures maximum legibility against the dark background while maintaining a softer visual impact than pure white.

## Typography
Typography is the primary driver of the visual identity. This design system utilizes a high-contrast pairing:

*   **Headlines (Syne):** Set in Extra Bold weights with tight leading (line-height) and negative letter-spacing for a "block-like" editorial feel. Headline-XL is intended for hero sections and should often be used with solid color blocking.
*   **Body (Inter):** Chosen for its neutral, highly readable characteristics. Body text should maintain generous line-height to ensure comfort during long-form reading.
*   **Labels:** All labels and utility text use Inter Bold in uppercase to contrast with the more expressive Syne headlines.

## Layout & Spacing
The layout follows a **Fixed Grid** philosophy inspired by print journalism.

*   **Desktop:** A 12-column grid with a max-width of 1440px. Use 4rem margins to create an "airy" frame around the content.
*   **Tablet:** An 8-column grid with 2rem margins.
*   **Mobile:** A 4-column grid with 1rem margins.

Spacing is governed by a strict rhythm. Large "block-gaps" (6rem) should separate major content sections to emphasize the structured minimalism. Content should be "blocked" together using solid background fills or sharp borders rather than relying on proximity alone.

## Elevation & Depth
This design system rejects traditional shadows in favor of **Tonal Layers** and **Bold Outlines**. 

*   **Surface Hierarchy:** Level 0 is the primary charcoal background (#121212). Level 1 containers use a slightly lighter grey (#1E1E1E) or solid accent colors (Forest/Terracotta).
*   **Separation:** Depth is created through color blocking. When elements overlap, use a 1px solid border (Off-White at 20% opacity) rather than a shadow to define edges.
*   **Interaction:** On hover, elements should not "lift" (shadow); instead, they should change fill color or stroke weight, maintaining the flat, architectural integrity of the layout.

## Shapes
The shape language is uncompromisingly **Sharp**. 

*   **Corners:** All buttons, cards, and input fields must have 0px border-radius to reinforce the "structured" theme. 
*   **Icons:** Use linear, geometric icons with a consistent 2px stroke weight. Avoid rounded terminals; opt for butt caps and miter joins to match the sharp UI.

## Components
Consistent component styling ensures the magazine-style aesthetic remains cohesive:

*   **Buttons:** Rectangular blocks with no rounding. Primary buttons use the Crimson Red background with Off-White text. Secondary buttons use a 2px stroke with no fill.
*   **Content Cards:** Large rectangular blocks with solid background fills (#1E1E1E). Text within cards should be aligned to a strict internal padding (usually 2rem).
*   **Input Fields:** Bottom-border only or 1px full-stroke rectangles. Use Inter for placeholder text and labels. Focus states are indicated by a change in border color to Terracotta.
*   **Chips/Labels:** Small, solid-fill rectangles (Forest Green or Terracotta) with uppercase Inter text. These should look like "tags" in a print catalog.
*   **Lists:** Items separated by 1px solid lines. No bullets; use typography weight (Bold) to distinguish list items from descriptions.
*   **Magazine Blocks:** A unique component consisting of a full-width section with a background color (Forest or Terracotta) and Headline-XL text, used to introduce new sections or highlight key quotes.